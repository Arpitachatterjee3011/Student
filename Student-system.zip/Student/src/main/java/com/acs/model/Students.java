package com.acs.model;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
    @Entity
	@Table(name="studentstable")
	public class Students {

		@Id
		@Column(name="studentid")
			private int stuid;
		@Column(name="studentName")
			private String name;
		@Column(name="studentDob")
		    private LocalDate dob;
		@Column(name="studentAge")
		    private int age;
		  
			public Students() {
				
			}
			
			public Students(int stuid, String name, LocalDate dob, double salary, String email,int age,String address,long phoneno,String jobpost) {
				super();
				this.stuid = stuid;
				this.name = name;
				this.dob = dob;
				this.age = age;	
			}
			
			
			public int getStuid() {
				return stuid;
			}

			public void setStuid(int stuid) {
				this.stuid = stuid;
			}

			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public LocalDate getDob() {
				return dob;
			}
			public void setDob(LocalDate dob) {
				this.dob = dob;
			}
		
			public int getAge() {
				return age;
			}
			public void setAge(int age) {
				this.age = age;
			}

			
}
