package com.acs.model;
import java.time.LocalDate;
import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;	
 @Entity
 @Table(name="attendence")
public class Attendence {
		//@GeneratedValue(strategy=GenerationType.AUTO)
	 @Id
	 @Column(name="attid")
	    private int attid;
		@Column(name="workinghours")
		private int workinghours;
		@Column(name="daydate")
		private LocalDate day_date;
		@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
		private List<Employee> employee;
		public Attendence() {
			// TODO Auto-generated constructor stub
		}
		public Attendence(int attid,int workinghours, LocalDate day_date, Employee employee) {
			super();
			this.attid = attid;
			this.workinghours = workinghours;
			this.day_date = day_date;
			//this.employee = employee;
		}
		
		public int getAttid() {
			return attid;
		}
		public void setAttid(int attid) {
			this.attid = attid;
		}
		public int getWorkinghours() {
			return workinghours;
		}
		public void setWorkinghours(int workinghours) {
			this.workinghours = workinghours;
		}
		public LocalDate getDay_date() {
			return day_date;
		}
		public void setDay_date(LocalDate day_date) {
			this.day_date = day_date;
		}
		public List<Employee> getEmployee() {
			return employee;
		}
		public void setEmployee(List<Employee> employee) {
			this.employee = employee;
		}	

	}


