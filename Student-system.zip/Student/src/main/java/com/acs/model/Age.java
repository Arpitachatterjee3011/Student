package com.acs.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Agetable")
	public class Age
	{
	  @Id
	  @Column(name="ageid")
	  private int ageid;
	  @Column( name="years")
	   private int years;
	  @Column(name="days")
	   private int days;
	  @Column(name="months")
	   private int months;
	  @OneToOne
	  private Students student;

	   private Age()
	   {
	      //Prevent default constructor
	   }

	   public Age(int ageid, int days, int months, int years)
	   {
		   this.ageid = ageid;
	      this.days = days;
	      this.months = months;
	      this.years = years;
	   }

	   
	  
	   public int getAgeid() {
		return ageid;
	}

	public void setAgeid(int ageid) {
		this.ageid = ageid;
	}

	public int getYears() {
		return years;
	}

	public void setYears(int years) {
		this.years = years;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public int getMonths() {
		return months;
	}

	public void setMonths(int months) {
		this.months = months;
	}

	@Override
	   public String toString()
	   {
	      return years + " Years, " + months + " Months, " + days + " Days";
	   }

}
