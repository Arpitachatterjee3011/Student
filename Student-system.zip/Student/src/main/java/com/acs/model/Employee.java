package com.acs.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="emptable")
public class Employee {
	@Id
	@Column(name="employeeid")
		private int empid;
	@Column(name="employee_name")
		private String name;
	@Column(name="employee_salary")
		private double salary;

		public Employee() {
			
		}
		public Employee(int empid, String name, double salary) {
			super();
			this.empid = empid;
			this.name = name;
			this.salary = salary;	
		}
		public int getEmpid() {
			return empid;
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		
		
}

