package com.acs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acs.dao.IStudentRepository;
import com.acs.model.Students;
@Service
public class StudentService {

	@Autowired
	private IStudentRepository repo;
	
	public List<Students> getAllStudents() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public Students getStudentsById(int sid) {
		// TODO Auto-generated method stub
		Optional<Students> op=repo.findById(sid);
		if(op.isPresent())
			return op.get();
		else
			return null;
	}

	public String createStudents(Students stu) {
		// TODO Auto-generated method stub
		repo.save(stu);
		return"student create with id:"+stu.getStuid();
	}

	public String updateStudents(Students stu) {
		// TODO Auto-generated method stub
		Students stu1=getStudentsById(stu.getStuid());
		if(stu1!=null) {
			repo.saveAndFlush(stu);
			return "Student updated";
		}
		else {
			return "student id not found";
		}
	}

}
