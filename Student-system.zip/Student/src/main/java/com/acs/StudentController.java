package com.acs;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acs.exception.StudentNotFoundException;
import com.acs.model.Students;
import com.acs.service.StudentService;

@RestController
@RequestMapping("studentss")
@CrossOrigin("http://localhost:4200")
public class StudentController {

	@Autowired
	private StudentService service;
	
	@GetMapping(produces= {"application/xml","application/json"})
	public List<Students> getAllStudents() {
		return service.getAllStudents();
	}
	
	@GetMapping("/{sid}")
	public ResponseEntity<Students> getEmployee(@PathVariable int sid) throws StudentNotFoundException {
		Students stu = service.getStudentsById(sid);
		if (stu != null)
			return new ResponseEntity<Students>(stu, HttpStatus.OK);
		else
			//return new ResponseEntity("employee not found", HttpStatus.NOT_FOUND);
			throw new StudentNotFoundException("student with given "+sid+" not found");
	}
	
	@PostMapping(consumes = { "application/json", "application/xml" })
	public String createEmployee(@RequestBody Students stu) {
		return service.createStudents(stu);
	}
	
	@PutMapping(consumes = { "application/json", "application/xml" })
	public String updateStudents(@RequestBody Students stu) {
		return service.updateStudents(stu);
	}
}
