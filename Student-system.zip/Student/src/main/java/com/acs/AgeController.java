package com.acs;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acs.model.Age;
import com.acs.model.Students;
import com.acs.service.AgeService;
@RestController
@RequestMapping("Ages")
public class AgeController {

	@Autowired
	private AgeService service;

	@GetMapping(produces= {"application/xml","application/json"})
	public List<Age> getAllAge() {
		return service.getAllAge();
	}
	
	@GetMapping(produces= {"application/xml","application/json"})
	public List<Age> getAgebtw18to25(){
		return service.getAgebtw18to25(0);
	}

//	 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//     Date birthDate = sdf.parse("02/05/1995");
//     Age age = calculateAge(birthDate);
//     System.out.println(age);
}
