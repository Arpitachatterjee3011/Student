package com.acs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.acs.model.Age;
@Repository
public interface IAgeRepository extends JpaRepository<Age, Integer>{

}
